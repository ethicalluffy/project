class WeightContainsNone(Exception):
    """ A weight contains a None value which makes a weight computation
    impossible."""
    pass
