Click Student, Reports in the navigation menu

See [Course Grades specification](specs/course_grades)

# Templates

Create report cards, transcripts, and more.

## Template Variables

### grade.get_grade()

**letter_and_number** - Shows results like `85 (B)`

