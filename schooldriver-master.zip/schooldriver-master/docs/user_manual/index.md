Welcome to the teacher manual. This is the index page
